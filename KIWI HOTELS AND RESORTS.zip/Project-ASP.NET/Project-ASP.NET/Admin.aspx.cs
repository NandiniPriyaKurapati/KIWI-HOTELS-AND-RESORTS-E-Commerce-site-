﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

public partial class Admin : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void loginbtn_Click(object sender, EventArgs e)
    {
        if (FormsAuthentication.Authenticate(txtadmin.Text, txtpsswrdadmin.Text))
        {
            Response.Redirect("Details.aspx");

        }
        else
        {
            errlabel.Text = "Only Admin Has Previlages to Login to the system";
        }

    }
}