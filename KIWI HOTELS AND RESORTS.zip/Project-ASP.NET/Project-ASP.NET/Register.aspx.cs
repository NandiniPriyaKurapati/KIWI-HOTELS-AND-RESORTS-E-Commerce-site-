﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Register : System.Web.UI.Page
{
    private string connectionString = WebConfigurationManager.ConnectionStrings["Hotel"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void regbtn_Click(object sender, EventArgs e)
    {
        if (!IsValid)
        {

            outlabel.Text = "Please fill out the information.";
            return;
        }
        else
        {

            // Define ADO.NET objects.
            string insertSQL;
            insertSQL = "INSERT INTO [USERTBL] (";
            insertSQL += "FirstName, LastName, UserName, ";
            insertSQL += "Password, PhoneNumber, EmailID) ";
            insertSQL += "VALUES (";
            insertSQL += "@fname, @lname, ";
            insertSQL += "@uname, @password, @phone, @email)";

            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(insertSQL, con);

            // Add the parameters.
            cmd.Parameters.AddWithValue("@fname", txtfname.Text);
            cmd.Parameters.AddWithValue("@lname", txtlname.Text);
            cmd.Parameters.AddWithValue("@uname", txtuname.Text);
            cmd.Parameters.AddWithValue("@password", txtpsswrd.Text);
            cmd.Parameters.AddWithValue("@phone", txtphone.Text);
            cmd.Parameters.AddWithValue("@email", txtemail.Text);
            
            // Try to open the database and execute the update.
            int added = 0;
            try
            {
                con.Open();
                added = cmd.ExecuteNonQuery();
                Response.Redirect("Booking.aspx");
            }
            catch (Exception err)
            {
                outlabel.Text = "Please Fill In proper Details. ";
                outlabel.Text += err.Message;
            }
            finally
            {
                con.Close();
            }
        }

    }
    protected void clrbtn_Click(object sender, EventArgs e)
    {
        txtfname.Text = "";
        txtlname.Text = "";
        txtuname.Text = "";
        txtpsswrd.Text = "";
        txtphone.Text = "";
        txtemail.Text = "";
    }
}