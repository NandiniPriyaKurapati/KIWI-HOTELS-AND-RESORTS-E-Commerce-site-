﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Booking : System.Web.UI.Page
{
    private string connectionString = WebConfigurationManager.ConnectionStrings["Hotel"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void Bkbtn_Click(object sender, EventArgs e)
    {
        if (!IsValid)
        {

            outlbl.Text = "Please fill out the information.";
            return;
        }
        else
        {

            // Define ADO.NET objects.
            string insertSQL;
            insertSQL = "INSERT INTO [BOOKINGTBL] (";
            insertSQL += "Suit, Room, indate, outdate, ";
            insertSQL += "cost) ";
            insertSQL += "VALUES (";
            insertSQL += "@suit, @room, ";
            insertSQL += "@indate, @outdate)";

            SqlConnection con = new SqlConnection(connectionString);
            SqlCommand cmd = new SqlCommand(insertSQL, con);

            // Add the parameters.
            cmd.Parameters.AddWithValue("@suit",  ddllist.SelectedItem.Text);
            cmd.Parameters.AddWithValue("@room", txtroom.Text);
            cmd.Parameters.AddWithValue("@indate", Incal.SelectedDate.ToString());
            cmd.Parameters.AddWithValue("@outdate", outcal.SelectedDate.ToString());
          
            // Try to open the database and execute the update.
            int added = 0;
            try
            {
                con.Open();
                added = cmd.ExecuteNonQuery();
                Response.Redirect("Booking.aspx");
            }
            catch (Exception err)
            {
                outlbl.Text = "Please Fill In proper Details. ";
                outlbl.Text += err.Message;
            }
            finally
            {
                con.Close();
            }
        }

    }
    }
}