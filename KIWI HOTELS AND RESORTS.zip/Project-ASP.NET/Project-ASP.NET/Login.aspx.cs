﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;


public partial class Login : System.Web.UI.Page
{
    private string connectionString = WebConfigurationManager.ConnectionStrings["Hotel"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void loginbtn_Click(object sender, EventArgs e)
    
    {
        if (authentication(txtname.Text, txtpsswrd.Text))
        {
            Response.Redirect("Details.aspx");

        }
        else
        {
            errlabel.Text = "Username Or Paswordd you entered is wrong";
        }
    }
    protected void LinkButton1_Click(object sender, EventArgs e)
    {
        Response.Redirect("Register.aspx");
    }

    private bool authentication(string username, string password)
    {
        SqlConnection con = new SqlConnection(connectionString);
        SqlCommand cmd = new SqlCommand("spAuthentication", con);
        cmd.CommandType = CommandType.StoredProcedure;

       // string enpassword = FormsAuthentication.HashPasswordForStoringInConfigFile(password, "SHA1");

        SqlParameter parmusername = new SqlParameter("@Username", username);
        SqlParameter parmpassword = new SqlParameter("@Password", password);

        cmd.Parameters.Add(parmusername);
        cmd.Parameters.Add(parmpassword);

        con.Open();
        int ReturnCode = (int)cmd.ExecuteScalar();
        return ReturnCode == 1;

    }

}