﻿Create Procedure spAuthentication
	@UserName varchar(25),
	@password varchar(25)
	
as 
Begin
   Declare @count int

   Select @count = COUNT(UserName) from USERTBL
     where [UserName] = @UserName and [Password] = @password

   if(@count = 1)
  
	begin 
		select 1 as ReturnCode
		End
	Else

	begin 
		select -1 as ReturnCode
		End
		End